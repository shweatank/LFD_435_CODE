# Understanding and Flow

### Questions:
1. Understand the concept of the device-tree.


### Flow:
1. Define the gpio device tree (.dts)
2. convert it to the .dtb
3. copy it to the boot/overlays/
4. add the file in /boot/overlays/config.txt
