#include <unistd.h>
int main(){

	write(1, "Sanket\n", 7);
}
